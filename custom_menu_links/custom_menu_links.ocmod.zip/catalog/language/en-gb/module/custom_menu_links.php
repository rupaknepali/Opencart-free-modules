<?php
// No language strings needed for the catalog side.

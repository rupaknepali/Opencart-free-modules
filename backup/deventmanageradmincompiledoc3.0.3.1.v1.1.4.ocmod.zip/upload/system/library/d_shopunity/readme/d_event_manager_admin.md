#d_event_manager_admin

Manage your events. Create, edit and delete events. Run tests to see if the events are working properly.

<?php 
$_['d_seo_module_url_redirect_setting'] = array(
	'list_limit' => '10',
	'stores_id' => array()
);
?>
<?php
// Text
$_['text_target_keyword']						= 'Target Keyword';

?>
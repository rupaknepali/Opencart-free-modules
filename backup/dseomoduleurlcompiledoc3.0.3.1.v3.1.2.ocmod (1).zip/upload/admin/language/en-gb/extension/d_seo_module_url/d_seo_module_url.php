<?php
// Text
$_['text_category'] 							= 'Category';
$_['text_product'] 								= 'Product';
$_['text_manufacturer']							= 'Manufacturer';
$_['text_information'] 							= 'Information';
$_['text_custom_page'] 							= 'Custom Page';
$_['text_url_keyword']							= 'URL Keyword';
$_['text_insert_target_keyword'] 				= 'Insert Target Keyword';
$_['text_keyword_number'] 						= 'Number of keyword';

// Help
$_['help_generate_category_url_keyword']		= 'Generate URL Keyword <span class="info-window-item" data-href="https://opencartseomodule.com/autogenerate-urls-for-all-pages"><i class="fa fa-question"></i></span>';
$_['help_generate_product_url_keyword']			= 'Generate URL Keyword <span class="info-window-item" data-href="https://opencartseomodule.com/autogenerate-urls-for-all-pages"><i class="fa fa-question"></i></span>';
$_['help_generate_manufacturer_url_keyword']	= 'Generate URL Keyword <span class="info-window-item" data-href="https://opencartseomodule.com/autogenerate-urls-for-all-pages"><i class="fa fa-question"></i></span>';
$_['help_generate_information_url_keyword']		= 'Generate URL Keyword <span class="info-window-item" data-href="https://opencartseomodule.com/autogenerate-urls-for-all-pages"><i class="fa fa-question"></i></span>';

?>
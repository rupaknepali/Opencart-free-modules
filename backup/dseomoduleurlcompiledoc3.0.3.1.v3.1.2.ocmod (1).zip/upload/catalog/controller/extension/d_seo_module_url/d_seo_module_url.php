<?php
class ControllerExtensionDSEOModuleURLDSEOModuleURL extends Controller {
	private $codename = 'd_seo_module_url';
	private $route = 'extension/d_seo_module_url/d_seo_module_url';
	private $config_file = 'd_seo_module_url';
	private $error = array(); 
		
	/*
	*	Functions for SEO Module URL.
	*/
	
	
	
}
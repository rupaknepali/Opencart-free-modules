<?php
// Heading
$_['heading_title_main']						= 'SEO Module';

// Text
$_['text_category']								= 'Category';
$_['text_product']								= 'Product';
$_['text_manufacturer']							= 'Manufacturer';
$_['text_information']							= 'Information';
$_['text_custom_page']							= 'Custom Page';
$_['text_target_keyword']						= 'Target Keyword';

// Help
$_['help_target_keyword']						= 'Target Keyword is multilingual field, which is important for SEO and must be unique for each page and language.';

?>
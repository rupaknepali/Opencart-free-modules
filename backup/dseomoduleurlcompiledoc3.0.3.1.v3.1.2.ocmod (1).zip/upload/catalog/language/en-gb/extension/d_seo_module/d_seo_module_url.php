<?php
// Heading
$_['heading_title_main']  						= 'SEO Module URL';

// Text
$_['text_url_keyword']							= 'URL Keyword';
$_['text_category_id']        					= 'Category Path';

// Help
$_['help_url_keyword']							= 'URL Keyword is multilingual field, which defines the url of the page and must be unique for each page.';
$_['help_category_id']							= 'Category Path specifies the unique path to the product in product links and breadcrumbs.';

?>
<?php
$_['d_blog_module_demo'] = array(
    'text'        => 'Blog',
    'description' => '<h4>Demo Data for Basic Blog</h4><p>You will replace all the Blog posts, categories, reviews and authors with the default settings. It is a great starting point to understend how the Blog Module works. You can then edit the posts to fit your needs. Remeber that this option will delete anything that you already have in your Blog so please be carefule. We adivise you to do a database backup first.</p>',
    'sql'         => 'd_blog_module.sql'
);

<?php
$_['text_title']             = 'Blog posts';
$_['text_description']       = 'Add your posts from blog module';

$_['entry_title']            = 'Title';
$_['entry_mode']             = 'Type posts';
$_['entry_categories']          = 'Blog categories';
$_['entry_posts']            = 'Posts';

$_['text_latest']            = 'Latest';
$_['text_featured']          = 'Featured';
$_['text_popular']           = 'Popular';
$_['text_custom_products']   = 'Custom Posts';
$_['text_custom_categories'] = 'Custom Categories';
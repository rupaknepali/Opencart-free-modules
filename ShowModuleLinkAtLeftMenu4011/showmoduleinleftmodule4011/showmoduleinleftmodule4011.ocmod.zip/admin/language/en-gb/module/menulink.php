<?php

$_['menu_showmoduleinleftmodule4011'] = 'Modules';

// Heading
$_['heading_title'] = 'Show Extra links';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified the Webocreation theme!';
$_['text_edit'] = 'Edit Webocreation Theme';

// Entry
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the Webocreation theme!';

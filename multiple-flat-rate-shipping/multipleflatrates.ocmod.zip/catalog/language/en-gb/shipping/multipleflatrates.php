<?php
// Heading
$_['heading_title'] = 'Multiple flat rates Based Shipping';

// Text
$_['text_multipleflatrates']   = 'Flat Rate:';
var testRequire = require('./test');

window.onload = function() {
    testRequire();
  };

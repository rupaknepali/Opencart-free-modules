# opencart-gulp-template

## Starter gulp template for opencart 3

1. download or clone repo to **catalog/view/theme**
2. rename folder **opencart-gulp-template** to **YOUR-THEME-NAME**
3. modify *proxy* property in **gulp-task/browser-sync.js**
4. run ``` yarn install ```
5. ```gulp``` - for run.

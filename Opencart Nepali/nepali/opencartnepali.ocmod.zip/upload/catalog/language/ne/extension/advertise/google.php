<?php

// Text
$_['text_cron_email_message'] = '<p>This is an automated report of the latest CRON task performed by your Google Shopping extension.</p><p>%s</p>';
$_['text_cron_email_subject'] = 'CRON job report - Google Shopping on OpenCart';
$_['text_per_day']            = '$%s / day';

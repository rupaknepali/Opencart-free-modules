<?php

// Text
$_['text_login']                   = 'Login';
$_['text_register']                = 'Register Account';
$_['text_forgotten']               = 'Forgotten Password';

// Entry
$_['entry_email']                  = 'E-Mail Address';
$_['entry_password']               = 'Password';
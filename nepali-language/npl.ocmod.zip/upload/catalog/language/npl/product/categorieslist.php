<?php
// Text
$_['title']        = 'All Categories';
$_['meta_title']        = 'All Categories meta title';
$_['meta_description']  = 'All Categories meta description';
$_['meta_keyword']      = 'All Categories meta keyword';
$_['categories_text']   = 'This is categories list page 2';

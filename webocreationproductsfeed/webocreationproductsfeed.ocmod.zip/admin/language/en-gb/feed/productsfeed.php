<?php
// Heading
$_['heading_title']          = 'Products feed';

// Text
$_['text_extension']         = 'Extensions';
$_['text_success']           = 'Success: You have modified Products feed!';
$_['text_edit']              = 'Edit Products feed';


// Entry
$_['entry_google_category']  = 'Google Category';
$_['entry_category']         = 'Category';
$_['entry_data_feed']        = 'Data Feed Url';
$_['entry_status']           = 'Status';

// Error
$_['error_permission']       = 'Warning: You do not have permission to modify Products feed!';
<?php
class ModelExtensionModuleShoppinglists extends Model {
	public function createSchemas() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "customer_shoppinglist_product`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "customer_shoppinglist`");

		$this->db->query("CREATE TABLE `" . DB_PREFIX . "customer_shoppinglist` (
			`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
			`name` VARCHAR(255) NOT NULL,
			`customer_id` INT NOT NULL,
			`date_created` DATETIME NOT NULL,
			PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

		$this->db->query("CREATE TABLE `" . DB_PREFIX . "customer_shoppinglist_product` (
			`shopping_list` INT UNSIGNED NOT NULL,
			`product_id` INT NOT NULL,
			`quantity` SMALLINT NOT NULL,
			`has_option` TINYINT(1) NOT NULL,
			`is_recurring` TINYINT(1) NOT NULL,
			`date_added` DATETIME NOT NULL,
			PRIMARY KEY (`shopping_list`,`product_id`),
			FOREIGN KEY (`shopping_list`) REFERENCES `" . DB_PREFIX . "customer_shoppinglist`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
		) ENGINE=InnoDB");

		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_delete_customer`");
		$this->db->query("
			CREATE TRIGGER `shoppinglists_after_delete_customer` AFTER DELETE ON `" . DB_PREFIX . "customer`
			FOR EACH ROW BEGIN
				DELETE FROM `" . DB_PREFIX . "customer_shoppinglist` WHERE `customer_id` = OLD.`customer_id`;
			END
		");

		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_delete_product`");
		$this->db->query("
			CREATE TRIGGER `shoppinglists_after_delete_product` AFTER DELETE ON `" . DB_PREFIX . "product`
			FOR EACH ROW BEGIN
				DELETE FROM `" . DB_PREFIX . "customer_shoppinglist_product` WHERE `product_id` = OLD.`product_id`;
			END
		");

		/*$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_update_product`");
		$this->db->query("
			CREATE TRIGGER `shoppinglists_after_update_product` AFTER UPDATE ON `" . DB_PREFIX . "product`
			FOR EACH ROW BEGIN
				IF (NEW.`status` != OLD.`status`) THEN
					UPDATE `" . DB_PREFIX . "customer_shoppinglist_product` SET `status` = NEW.`status` WHERE `product_id` = OLD.`product_id`;
				END IF;
			END
		");*/

		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_insert_product_option`");
		$this->db->query("
			CREATE TRIGGER `shoppinglists_after_insert_product_option` AFTER INSERT ON `" . DB_PREFIX . "product_option`
			FOR EACH ROW BEGIN
				UPDATE `" . DB_PREFIX . "customer_shoppinglist_product` SET `has_option` = 1 WHERE `product_id` = NEW.`product_id`;
			END
		");

		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_delete_product_option`");
		$this->db->query("
			CREATE TRIGGER `shoppinglists_after_delete_product_option` AFTER DELETE ON `" . DB_PREFIX . "product_option`
			FOR EACH ROW BEGIN
				DECLARE options INTEGER;
				SELECT COUNT(`product_option_id`) INTO options FROM `" . DB_PREFIX . "product_option` WHERE `product_id` = OLD.`product_id`;
				IF (options = 0) THEN
					UPDATE `" . DB_PREFIX . "customer_shoppinglist_product` SET `has_option` = 0 WHERE `product_id` = OLD.`product_id`;
				END IF;
			END
		");

		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_insert_product_recurring`");
		$this->db->query("
			CREATE TRIGGER `shoppinglists_after_insert_product_recurring` AFTER INSERT ON `" . DB_PREFIX . "product_recurring`
			FOR EACH ROW BEGIN
				UPDATE `" . DB_PREFIX . "customer_shoppinglist_product` SET `is_recurring` = 1 WHERE `product_id` = NEW.`product_id`;
			END
		");

		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_delete_product_recurring`");
		$this->db->query("
			CREATE TRIGGER `shoppinglists_after_delete_product_recurring` AFTER DELETE ON `" . DB_PREFIX . "product_recurring`
			FOR EACH ROW BEGIN
				DECLARE recurring INTEGER;
				SELECT COUNT(`product_id`) INTO recurring FROM `" . DB_PREFIX . "product_recurring` WHERE `product_id` = OLD.`product_id`;
				IF (recurring = 0) THEN
					UPDATE `" . DB_PREFIX . "customer_shoppinglist_product` SET `is_recurring` = 0 WHERE `product_id` = OLD.`product_id`;
				END IF;
			END
		");

		#$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = 0, `code` = 'shoppinglists', `key` = 'shoppinglists_status', `value` = '1', `serialized` = 0");
	}

	public function dropSchemas() {
		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_delete_customer`");
		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_delete_product_recurring`");
		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_insert_product_recurring`");
		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_delete_product_option`");
		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_insert_product_option`");
		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_update_product`");
		$this->db->query("DROP TRIGGER IF EXISTS `shoppinglists_after_delete_product`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "customer_shoppinglist_product`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "customer_shoppinglist`");
	}
}
?>
<?php
$_['heading_title'] = 'Multiple Shopping Lists';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified "Multiple Shopping Lists" module!';
$_['text_edit']        = 'Edit "Multiple Shopping Lists" Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify "Multiple Shopping Lists" module!';?>

<?php
// Heading
$_['heading_title'] = 'My Shopping Lists';

// Text
$_['text_items']                              = '%s item(s) - %s';
$_['text_account']                            = 'Account';
$_['text_my_shoppinglists']                   = 'My Shopping Lists';
$_['text_new_shoppinglist']                   = 'New Shopping List';
$_['text_instock']                            = 'In Stock';
$_['text_success_shoppinglist_added']         = 'Success: Your shopping list <b>%s</b> has been created.';
$_['text_success_shoppinglist_deleted']       = 'Success: Your shopping list <b>%s</b> has been deleted.';
$_['text_success_product_added_to_list']      = 'Success: <b>%s</b> has been added to your shopping list <b>%s</b>.';
$_['text_success_product_removed_from_list']  = 'Success: <b>%s</b> has been removed from your shopping list <b>%s</b>.';
$_['text_success_product_added_to_cart']      = 'Success: <a href="%s">%s</a> has been added to your <a href="%s">shopping cart</a>.';
$_['text_success_products_added_to_cart']     = 'Success: %s <a href="%s">%s</a> have been added to your <a href="%s">shopping cart</a>.';
$_['text_success_shoppinglist_added_to_cart'] = 'Success: The products in your shopping list have been added to your <a href="%s">shopping cart</a>.';
$_['text_success_shoppinglist_saved']         = 'Success: Your shopping list has been saved.';
$_['text_warning_db_error']                   = 'Warning: Database error! Please try again later.';
$_['text_warning_shoppinglist_not_added']     = 'Warning: Database error! Your shopping list <b>%s</b> couldn\'t be created.';
$_['text_warning_shoppinglist_id_missing']    = 'Warning: Shopping list ID is missing!';
$_['text_warning_invalid_shoppinglist_id']    = 'Warning: Invalid shopping list ID!';
$_['text_warning_wrong_shoppinglist_id']      = 'Warning: Database error, or wrong shopping list ID!';
$_['text_warning_quantity_not_available']     = 'Warning: <b>%s</b> is not available in that quantity!';
$_['text_warning_minimum']                    = 'Warning: Minimum order amount for <b>%s</b> is <b>%s</b>!';
$_['text_no_shoppinglists']                   = 'You don\'t have any shopping lists yet!';
$_['text_create_new_shoppinglist']            = 'Please create a <a href="%s">new</a> shopping list first.';
$_['text_you_can_add_product']                = 'You can add <b>%s</b> to your shopping list now.';
$_['text_no_products']                        = 'You don\'t have any products in your shopping list yet! To add a product to your shopping list, go to any product page and click on "Add to shopping list" button/link or click on any shopping list icon %s related to a product.';
$_['text_add_to_cart']                        = 'Add to cart';
$_['text_add_product']                        = 'Add product';
$_['text_add_product_to_shoppinglist']        = 'Add <b>%s</b> to your shopping list.';
$_['text_add_product_to_shoppinglists']       = 'Add <b>%s</b> to your shopping lists.';
$_['text_warning_product_exists']             = 'Warning: <b>%s</b> is already in your shopping list <b>%s</b>!';
$_['text_warning_product_id_missing']         = 'Warning: Product ID is missing!';
$_['text_warning_invalid_product_id']         = 'Warning: Invalid product ID!';
$_['text_warning_wrong_product_id']           = 'Warning: Database error, or wrong product ID!';
$_['text_warning_choose_shoppinglist']        = 'Warning: Please choose which shoppinglist you wish to add <b>%s</b> to!';
$_['text_add']                                = 'Add';


// Button
$_['button_show_list']                 = 'Show List';
$_['button_new_list']                  = 'New List';
$_['button_buy']                       = 'Buy';
$_['button_add_list_to_shopping_cart'] = 'Add list to shopping cart';
$_['button_save_list']                 = 'Save List';

// Entry
$_['entry_shoppinglist_name'] = 'Shopping List Name';

// Error
$_['error_missing_name']       = 'Name is missing!';
$_['error_name_too_long']      = 'Name is too long!';
$_['error_name_invalid']       = 'Invalid name!';
$_['error_name_exists']        = 'That name exists already!';
$_['error_missing_quantity']   = 'Quantity is missing!';
$_['error_quantity_invalid']   = 'Quantity should be a number!';
$_['error_required']           = '%s required!';
$_['error_recurring_required'] = 'Please select a payment recurring!';

// Column
$_['column_image']        = 'Image';
$_['column_product']      = 'Product';
$_['column_stock']        = 'Stock';
$_['column_price']        = 'Unit Price';
$_['column_quantity']     = 'Quantity';
$_['column_action']       = 'Action';
$_['column_shoppinglist'] = 'Shopping List';

<?php
class ControllerAccountShoppinglists extends Controller {
	private $error = array();
	
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/shoppinglists', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/shoppinglists');
		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home', '', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_my_shoppinglists'),
			'href' => $this->url->link('account/shoppinglists', '', true)
		);

		if (isset($this->session->data['warning'])) {
			$data['warning'] = $this->session->data['warning'];
			unset($this->session->data['warning']);

			$data['success'] = '';
		} elseif (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);

			$data['warning'] = '';
		} else {
			$data['success'] = '';
			$data['warning'] = '';
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$this->load->model('account/shoppinglists');

		if ((int)$this->model_account_shoppinglists->getTotalShoppinglists()) {
			// If there are some shopping lists.
			$data['shoppinglists'] = $this->model_account_shoppinglists->getShoppinglists();
			$data['button_show_list'] = $this->language->get('button_show_list');
			$data['button_delete'] = $this->language->get('button_delete');
		} else {
			$data['message_no_shoppinglists'] = $this->language->get('text_no_shoppinglists');
		}

		$data['back'] = $this->url->link('account/account', '', true);
		$data['button_back'] = $this->language->get('button_back');
		$data['new_list'] = $this->url->link('account/shoppinglists/newList', '', true);
		$data['button_new_list'] = $this->language->get('button_new_list');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('account/shoppinglists', $data));
	} // End function index.

	public function newList() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/shoppinglists', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/shoppinglists');

		$this->document->setTitle($this->language->get('text_new_shoppinglist'));
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home', '', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_my_shoppinglists'),
			'href' => $this->url->link('account/shoppinglists', '', true)
		);

		$this->load->model('catalog/product');

		$product_info = array();
		if (isset($this->request->get['product_id'])) {
			if (preg_match('/^[0-9]+$/', $this->request->get['product_id'])) {

				$product_info = $this->model_catalog_product->getProduct($this->request->get['product_id']);
				if ($product_info) {
					if ($product_info['status'] === 0) {
						$this->session->data['warning'] = $this->language->get('text_warning_wrong_product_id');
					}
				} else {
					$this->session->data['warning'] = $this->language->get('text_warning_wrong_product_id');
				}
			} else {
				$this->session->data['warning'] = $this->language->get('text_warning_invalid_product_id');
			}

			if (isset($this->session->data['warning'])) {
				$this->response->redirect($this->url->link('account/shoppinglists', '', true));
			}

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_new_shoppinglist'),
				'href' => $this->url->link('account/shoppinglists/newList', 'product_id=' . $product_info['product_id'], true)
			);

			$data['action'] = $this->url->link('account/shoppinglists/newList', 'product_id=' . $product_info['product_id'], true);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_new_shoppinglist'),
				'href' => $this->url->link('account/shoppinglists/newList', '', true)
			);

			$data['action'] = $this->url->link('account/shoppinglists/newList', '', true);
		}

		$data['heading_title'] = $this->language->get('text_new_shoppinglist');

		if (isset($this->request->post['shoppinglistname']) && $this->validateShoppinglistName($this->request->post['shoppinglistname'])) {
			$this->load->model('account/shoppinglists');

			$name = trim($this->request->post['shoppinglistname']);
			if ($this->model_account_shoppinglists->addShoppinglist($name)) {
				if (isset($product_info['product_id'])) {
					$this->session->data['success'] = sprintf($this->language->get('text_success_shoppinglist_added'), $name) . ' ' . sprintf($this->language->get('text_you_can_add_product'), $product_info['name']);
					$this->response->redirect($this->url->link('account/shoppinglists/add', 'product_id=' . $product_info['product_id'], true));
				} else {
					$this->session->data['success'] = sprintf($this->language->get('text_success_shoppinglist_added'), $name);
					$this->response->redirect($this->url->link('account/shoppinglists', '', true));
				}
			} else {
				$data['warning'] = $this->language->get('text_warning_db_error');
			}
			unset($name);
		}
		unset($product_info);

		if (isset($this->error['shoppinglist_name'])) {
			$data['error_shoppinglist_name'] = $this->error['shoppinglist_name'];
		} else {
			$data['error_shoppinglist_name'] = '';
		}

		$data['entry_name'] = $this->language->get('entry_shoppinglist_name');
		$data['back'] = $this->url->link('account/shoppinglists', '', true);
		$data['button_back'] = $this->language->get('button_back');
		$data['button_continue'] = $this->language->get('button_continue');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
			
		$this->response->setOutput($this->load->view('account/shoppinglists_new', $data));
	} // End function newList.

	public function delete() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/shoppinglists', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/shoppinglists');

		if (isset($this->request->get['shoppinglist_id'])) {
			if (preg_match('/^[0-9]+$/', $this->request->get['shoppinglist_id'])) {
				$this->load->model('account/shoppinglists');

				$name = $this->model_account_shoppinglists->getShoppinglistName($this->request->get['shoppinglist_id']);
				if ($name) {
					if ($this->model_account_shoppinglists->deleteShoppinglist($this->request->get['shoppinglist_id'])) {
						$this->session->data['success'] = sprintf($this->language->get('text_success_shoppinglist_deleted'), $name);
					} else {
						$this->session->data['warning'] = $this->language->get('text_warning_wrong_shoppinglist_id');
					}
				} else {
					$this->session->data['warning'] = $this->language->get('text_warning_db_error');
				}
				unset($name);
			} else {
				$this->session->data['warning'] = $this->language->get('text_warning_invalid_shoppinglist_id');
			}
		} else {
			$this->session->data['warning'] = $this->language->get('text_warning_shoppinglist_id_missing');
		}

		$this->response->redirect($this->url->link('account/shoppinglists', '', true));
	} // End function delete.

	public function show() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/shoppinglists', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		if (isset($this->session->data['warning'])) {
			$data['warning'] = $this->session->data['warning'];
			unset($this->session->data['warning']);
		} elseif (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		}

		if (!function_exists('mb_ucfirst')) {
			function mb_ucfirst($str, $encoding = "UTF-8", $lower_str_end = false) {
				$first_letter = mb_strtoupper(mb_substr($str, 0, 1, $encoding), $encoding);
				$str_end = '';
				if ($lower_str_end) {
					$str_end = mb_strtolower(mb_substr($str, 1, mb_strlen($str, $encoding), $encoding), $encoding);
				} else {
					$str_end = mb_substr($str, 1, mb_strlen($str, $encoding), $encoding);
				}
				$str = $first_letter . $str_end;
				return $str;
			}
		}

		$this->load->language('account/shoppinglists');
		$this->load->model('account/shoppinglists');

		if (isset($this->request->get['shoppinglist_id'])) {
			if (preg_match('/^[0-9]+$/', $this->request->get['shoppinglist_id'])) {
				$name = $this->model_account_shoppinglists->getShoppinglistName($this->request->get['shoppinglist_id']);
				if ($name) {
					$this->document->setTitle(mb_ucfirst($name));

					$data['breadcrumbs'] = array();

					$data['breadcrumbs'][] = array(
						'text' => $this->language->get('text_home'),
						'href' => $this->url->link('common/home', '', true)
					);

					$data['breadcrumbs'][] = array(
						'text' => $this->language->get('text_account'),
						'href' => $this->url->link('account/account', '', true)
					);

					$data['breadcrumbs'][] = array(
						'text' => $this->language->get('text_my_shoppinglists'),
						'href' => $this->url->link('account/shoppinglists', '', true)
					);

					$data['breadcrumbs'][] = array(
						'text' => mb_ucfirst($name),
						'href' => $this->url->link('account/shoppinglists/show', 'shoppinglist_id=' . $this->request->get['shoppinglist_id'], true)
					);

					$data['heading_title'] = mb_ucfirst($name);
				} else {
					$this->session->data['warning'] = $this->language->get('text_warning_db_error');
				}
				unset($name);
			} else {
				$this->session->data['warning'] = $this->language->get('text_warning_invalid_shoppinglist_id');
			}
		} else {
			$this->session->data['warning'] = $this->language->get('text_warning_shoppinglist_id_missing');
		}

		if (isset($this->session->data['warning'])) {
			$this->response->redirect($this->url->link('account/shoppinglists', '', true));
		}

		$_products = $this->model_account_shoppinglists->getProducts($this->request->get['shoppinglist_id']);

		if ($_products) { // If there are some products in shopping list.
			$data['column_image'] = $this->language->get('column_image');
			$data['column_product'] = $this->language->get('column_product');
			$data['column_stock'] = $this->language->get('column_stock');
			$data['column_price'] = $this->language->get('column_price');
			$data['column_quantity'] = $this->language->get('column_quantity');
			$data['column_action'] = $this->language->get('column_action');

			$this->load->model('catalog/product');
			$this->load->model('tool/image');

			$product_info = array();
			$data['products'] = array();
			$isRecurring = false;
			$hasOptions = false;
			$disabledProducts = 0;
			foreach ($_products as $key => $_product) {
				if ($_product['is_recurring'] == "1") {
					$isRecurring = true;
				}

				if ($_product['has_option'] == "1") {
					$hasOptions = true;
				}

				$data['products'][$key]['id'] = $_product['id'];
				$data['products'][$key]['quantity'] = $_product['quantity'];
				$data['products'][$key]['remove'] = $this->url->link('account/shoppinglists/remove', 'product_id=' . $_product['id'] . '&shoppinglist_id=' . $this->request->get['shoppinglist_id'], true);

				$product_info = $this->model_catalog_product->getProduct($_product['id']);
				if ($product_info) {
					$data['products'][$key]['name'] = $product_info['name'];

					if ($product_info['image']) {
						$image = $this->model_tool_image->resize($product_info['image'], $this->config->get($this->config->get('config_theme') . '_image_wishlist_width'), $this->config->get($this->config->get('config_theme') . '_image_wishlist_height'));
					} else {
						$image = false;
					}
					$data['products'][$key]['thumb'] = $image;
					unset($image);

					$data['products'][$key]['href'] = $this->url->link('product/product', 'product_id=' . $product_info['product_id'], true);

					$data['products'][$key]['disabled'] = false;
					if ($product_info['quantity'] <= 0) {
						$stock = $product_info['stock_status'];
						$data['products'][$key]['disabled'] = true;
						$disabledProducts++;
					} elseif ($this->config->get('config_stock_display')) {
						$stock = $product_info['quantity'];
					} else {
						$stock = $this->language->get('text_instock');
					}
					$data['products'][$key]['stock'] = $stock;
					unset($stock);

					if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
						$price = $this->currency->format($this->tax->calculate($product_info['price'], $product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
					} else {
						$price = false;
					}

					$data['products'][$key]['price'] = $price;
					unset($price);

					if ((float)$product_info['special']) {
						$special = $this->currency->format($this->tax->calculate($product_info['special'], $product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
					} else {
						$special = false;
					}

					$data['products'][$key]['special'] = $special;
					unset($special);
				} else {
					$this->session->data['warning'] = $this->language->get('text_warning_db_error');
				}
			}
			unset($product_info, $key, $_product);

			if (isset($this->request->post['bulk'])) {
				$_buy = array();
				foreach ($this->request->post as $key => $value) {
					if (preg_match('/^quantity_([0-9]+)$/', $key, $_matches)) {
						if ($this->validateQuantity($_matches[1])) {
							$_buy[$_matches[1]] = $this->request->post['quantity_' . $_matches[1]];
						}
					}
				}
				unset($key, $value);

				if (count($this->error)) {
					foreach ($this->error as $key => $val) {
						$data['error'][$key] = $val;
					}
				} else {
					foreach ($_buy as $key => $val) {
						if (!$data['products'][$key]['disabled']) {
							$this->cart->add($key, $val);
						}
					}
					$this->session->data['success'] = sprintf($this->language->get('text_success_shoppinglist_added_to_cart'), $this->url->link('checkout/cart', '', true));
					$this->response->redirect($this->url->link('account/shoppinglists/show', 'shoppinglist_id=' . $this->request->get['shoppinglist_id'], true));
				}
				unset($_buy, $key, $val);
			} elseif (isset($this->request->post['save'])) {
				$_save = array();
				foreach ($this->request->post as $key => $value) {
					if (preg_match('/^quantity_([0-9]+)$/', $key, $_matches)) {
						if ($this->validateQuantity($_matches[1])) {
							$_save[$_matches[1]] = $this->request->post['quantity_' . $_matches[1]];
						}
					}
				}
				unset($key, $value);

				if (count($this->error)) {
					foreach ($this->error as $key => $val) {
						$data['error'][$key] = $val;
					}
				} else {
					foreach ($_save as $key => $val) {
						$updated = $this->model_account_shoppinglists->updateProduct($this->request->get['shoppinglist_id'], $key, $val);
					}

					if ($updated) {
						$data['success'] = $this->language->get('text_success_shoppinglist_saved');
					} else {
						$data['warning'] = $this->language->get('text_warning_db_error');
					}
					unset($updated);
				}
				unset($_save, $key, $val);
			}

			$data['action'] = $this->url->link('account/shoppinglists/show', 'shoppinglist_id=' . $this->request->get['shoppinglist_id'], true);
			$data['add_to_cart'] = $this->language->get('text_add_to_cart');
			$data['button_remove'] = $this->language->get('button_remove');

			if (count($_products) > 1 && !$isRecurring && !$hasOptions && (count($_products) - $disabledProducts) > 1) {
				$data['button_buy_all'] = $this->language->get('button_add_list_to_shopping_cart');
			}

			$data['button_save_list'] = $this->language->get('button_save_list');
			unset($isRecurring, $hasOptions, $disabledProducts);
		} else {
			if ($this->request->server['HTTPS']) {
				$server = $this->config->get('config_ssl');
			} else {
				$server = $this->config->get('config_url');
			}

			$data['message_no_products'] = sprintf($this->language->get('text_no_products'),'<img src="' . $server . 'image/shoppinglists/shoppinglist.png" width="15" height="15" alt="" />');
			unset($server);
		}
		unset($_products);

		$data['back'] = $this->url->link('account/shoppinglists', '', true);
		$data['button_back'] = $this->language->get('button_back');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');

		if (isset($this->session->data['warning'])) {
			$this->response->redirect($this->url->link('account/shoppinglists', '', true));
		} else {
			$this->response->setOutput($this->load->view('account/shoppinglists_show', $data));
		}
	} // End function show.

	public function add() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/shoppinglists', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/shoppinglists');
		$this->load->model('catalog/product');

		$product_info = array();
		if (isset($this->request->get['product_id'])) {
			if (preg_match('/^[0-9]+$/', $this->request->get['product_id'])) {

				$product_info = $this->model_catalog_product->getProduct($this->request->get['product_id']);
				if ($product_info) {
					if ($product_info['status'] === 0) {
						$this->session->data['warning'] = $this->language->get('text_warning_wrong_product_id');
					}
				} else {
					$this->session->data['warning'] = $this->language->get('text_warning_wrong_product_id');
				}
			} else {
				$this->session->data['warning'] = $this->language->get('text_warning_invalid_product_id');
			}
		} else {
			$this->session->data['warning'] = $this->language->get('text_warning_product_id_missing');
		}

		if (isset($this->session->data['warning'])) {
			$this->response->redirect($this->url->link('account/shoppinglists', '', true));
		}

		$data = array();
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		}

		$this->document->setTitle($this->language->get('text_add_product'));

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home', '', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_my_shoppinglists'),
			'href' => $this->url->link('account/shoppinglists', '', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_add_product'),
			'href' => $this->url->link('account/shoppinglists/add', 'product_id=' . $product_info['product_id'], true)
		);

		$data['heading_title'] = $this->language->get('text_add_product');

		$this->load->model('account/shoppinglists');

		$data['shoppinglists'] = array();
		if ((int)$this->model_account_shoppinglists->getTotalShoppinglists()) {
			// If there are some shopping lists.
			$data['action'] = $this->url->link('account/shoppinglists/add', 'product_id=' . $product_info['product_id'], true);

			$_add = array();
			if (isset($this->request->post['add'])) {
				foreach ($this->request->post as $key => $value) {
					if (preg_match('/^quantity_([0-9]+)$/', $key, $_matches)) {
						if (isset($this->request->post['add_' . $_matches[1]])) {
							if ($this->validateQuantity($_matches[1])) {
								if ($this->model_account_shoppinglists->productExists($product_info['product_id'], $_matches[1])) {
									$shoppingListName = $this->model_account_shoppinglists->getShoppinglistName($_matches[1]);
									if ($shoppingListName != "") {
										$data['warning'] = (isset($data['warning']) && $data['warning'] != "") ? $data['warning'] . '<br />' . sprintf($this->language->get('text_warning_product_exists'), $product_info['name'], $shoppingListName): sprintf($this->language->get('text_warning_product_exists'), $product_info['name'], $shoppingListName);
									} else {
										$data['warning'] = $this->language->get('text_warning_db_error');
										break;
									}
									unset($shoppingListName);
								} else {
									$_add[$_matches[1]]['quantity'] = $value;
									$_add[$_matches[1]]['shoppinglist'] = $_matches[1];
								}
							}
						} else {
							if ($value != "") {
								$data['warning'] = sprintf($this->language->get('text_warning_choose_shoppinglist'), $product_info['name']);
								$this->validateQuantity($_matches[1]);
							}
						}
					}
				}
				unset($key, $value);

				if (count($this->error) || isset($data['warning'])) {
					if (count($this->error)) {
						foreach ($this->error as $key => $val) {
							$data['error'][$key] = $val;
						}
						unset($key, $val);
					}
				} else {
					if (count($_add)) {
						$product_options = $this->model_catalog_product->getProductOptions($product_info['product_id']);
						$option = (count($product_options)) ? 1: 0;
						$recurring = $this->model_account_shoppinglists->checkRecurringProduct($product_info['product_id']);
						unset($product_options);

						foreach ($_add as $key => $_list) {
							if ($this->model_account_shoppinglists->addProduct($_list['shoppinglist'], $product_info['product_id'], $_list['quantity'], $option, $recurring)) {
								$shoppingListName = $this->model_account_shoppinglists->getShoppinglistName($_list['shoppinglist']);
								$this->session->data['success'] = (isset($this->session->data['success']) && $this->session->data['success'] != "") ? $this->session->data['success'] . '<br />' . sprintf($this->language->get('text_success_product_added_to_list'), $product_info['name'], $shoppingListName): sprintf($this->language->get('text_success_product_added_to_list'), $product_info['name'], $shoppingListName);
								unset($shoppingListName);
							}
						}
						unset($recurring, $option, $key, $_list);

						if (isset($this->session->data['success'])) {
							$this->response->redirect($this->url->link('account/shoppinglists', '', true));
						}
					} else {
						$data['warning'] = sprintf($this->language->get('text_warning_choose_shoppinglist'), $product_info['name']);
					}
				}
			}
			unset($_add);

			$data['list_add'] = $this->language->get('text_add');
			$data['list_quantity'] = $this->language->get('column_quantity');
			$data['list_name'] = $this->language->get('column_shoppinglist');
			$data['shoppinglist_name'] = $this->language->get('entry_shoppinglist_name');
			$data['new_shoppinglist'] = $this->language->get('text_new_shoppinglist');
			$data['cancel'] = $this->url->link('common/home', '', true);
			$data['button_cancel'] = $this->language->get('button_cancel');
			$data['button_add'] = $this->language->get('text_add');

			$data['shoppinglists'] = $this->model_account_shoppinglists->getShoppinglists();
			if (count($data['shoppinglists']) === 1) {
				$data['message'] = sprintf($this->language->get('text_add_product_to_shoppinglist'), $product_info['name']);
			} else {
				$data['message'] = sprintf($this->language->get('text_add_product_to_shoppinglists'), $product_info['name']);
			}
		} else {
			$data['message'] = $this->language->get('text_no_shoppinglists') . ' ' . sprintf($this->language->get('text_create_new_shoppinglist'), $this->url->link('account/shoppinglists/newList', 'product_id=' . $product_info['product_id'], true));
		}
		unset($product_info);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('account/shoppinglists_add', $data));					
	} // End function add.

	public function remove() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/shoppinglists', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/shoppinglists');

		$product_info = array();
		if (isset($this->request->get['product_id'])) {
			if (preg_match('/^[0-9]+$/', $this->request->get['product_id'])) {
				$this->load->model('catalog/product');

				$product_info = $this->model_catalog_product->getProduct($this->request->get['product_id']);
				if ($product_info) {
					if ($product_info['status'] === 0) {
						$this->session->data['warning'] = $this->language->get('text_warning_wrong_product_id');
					}
				} else {
					$this->session->data['warning'] = $this->language->get('text_warning_wrong_product_id');
				}
			} else {
				$this->session->data['warning'] = $this->language->get('text_warning_invalid_product_id');
			}
		} else {
			$this->session->data['warning'] = $this->language->get('text_warning_product_id_missing');
		}

		$shoppinglistName = '';
		if (isset($this->request->get['shoppinglist_id'])) {
			if (preg_match('/^[0-9]+$/', $this->request->get['shoppinglist_id'])) {
				$this->load->model('account/shoppinglists');
				
				$shoppinglistName = $this->model_account_shoppinglists->getShoppinglistName($this->request->get['shoppinglist_id']);
				if (!$shoppinglistName) {
					$this->session->data['warning'] = (isset($this->session->data['warning'])) ? $this->session->data['warning'] . '<br />' . $this->language->get('text_warning_db_error'): $this->language->get('text_warning_db_error');
				}
			} else {
				$this->session->data['warning'] = (isset($this->session->data['warning'])) ? $this->session->data['warning'] . '<br />' . $this->language->get('text_warning_invalid_shoppinglist_id'): $this->language->get('text_warning_invalid_shoppinglist_id');
			}
		} else {
			$this->session->data['warning'] = (isset($this->session->data['warning'])) ? $this->session->data['warning'] . '<br />' . $this->language->get('text_warning_shoppinglist_id_missing'): $this->language->get('text_warning_shoppinglist_id_missing');
		}

		if (isset($this->session->data['warning'])) {
			$this->response->redirect($this->url->link('account/shoppinglists', '', true));
		}

		if ($this->model_account_shoppinglists->deleteProduct($this->request->get['product_id'], $this->request->get['shoppinglist_id'])) {
			$this->session->data['success'] = sprintf($this->language->get('text_success_product_removed_from_list'), $product_info['name'], $shoppinglistName);
		} else {
			$this->session->data['warning'] = $this->language->get('text_warning_db_error');
		}
		$this->response->redirect($this->url->link('account/shoppinglists/show', 'shoppinglist_id=' . $this->request->get['shoppinglist_id'], true));
	} // End function remove.

	public function addToCart() {
		$this->load->language('account/shoppinglists');

		$json = array();

		if (isset($this->request->post['product_id'])) {
			if (preg_match('/^[0-9]+$/', $this->request->post['product_id'])) {
				$product_id = (int)$this->request->post['product_id'];
			} else {
				$this->session->data['warning'] = $this->language->get('text_warning_invalid_product_id');
				$this->response->redirect($this->url->link('account/shoppinglists', '', true));
			}
		} else {
			$this->session->data['warning'] = $this->language->get('text_warning_product_id_missing');
			$this->response->redirect($this->url->link('account/shoppinglists', '', true));
		}

		$this->load->model('catalog/product');

		$product_info = $this->model_catalog_product->getProduct($product_id);

		if ($product_info) {
			if ($this->validateQuantity($product_id)) {
				$quantity = (int)$this->request->post['quantity_' . $product_id];
				if ($quantity < $product_info['quantity']) {
					if ($quantity < $product_info['minimum']) {
						$json['error']['quantity'] = sprintf($this->language->get('text_warning_minimum'), $product_info['name'], $product_info['minimum']);
					}
				} else {
					$json['error']['quantity'] = sprintf($this->language->get('text_warning_quantity_not_available'), $product_info['name']);
				}
			} else {
				$json['error']['quantity'] = $this->error['quantity_' . $product_id];
			}

			if (!$json) {
				$this->cart->add($product_id, $quantity);

				if ($quantity === 1) {
					$json['success'] = sprintf($this->language->get('text_success_product_added_to_cart'), $this->url->link('product/product', 'product_id=' . $product_id, true), $product_info['name'], $this->url->link('checkout/cart', '', true));
				} else {
					$json['success'] = sprintf($this->language->get('text_success_products_added_to_cart'), $quantity, $this->url->link('product/product', 'product_id=' . $product_id, true), $product_info['name'], $this->url->link('checkout/cart', '', true));
				}
			} else {
				if (!isset($json['error']['quantity'])) {
					$json['redirect'] = str_replace('&amp;', '&', $this->url->link('product/product', 'product_id=' . $product_id, true));
				}
			}

			// Unset all shipping and payment methods
			unset($this->session->data['shipping_method']);
			unset($this->session->data['shipping_methods']);
			unset($this->session->data['payment_method']);
			unset($this->session->data['payment_methods']);

			// Totals
			$this->load->model('extension/extension');

			$totals = array();
			$taxes = $this->cart->getTaxes();
			$total = 0;
		
			// Because __call can not keep var references so we put them into an array. 			
			$total_data = array(
				'totals' => &$totals,
				'taxes'  => &$taxes,
				'total'  => &$total
			);

			// Display prices
			if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
				$sort_order = array();

				$results = $this->model_extension_extension->getExtensions('total');

				foreach ($results as $key => $value) {
					$sort_order[$key] = $this->config->get($value['code'] . '_sort_order');
				}

				array_multisort($sort_order, SORT_ASC, $results);

				foreach ($results as $result) {
					if ($this->config->get($result['code'] . '_status')) {
						$this->load->model('extension/total/' . $result['code']);

						// We have to put the totals in an array so that they pass by reference.
						$this->{'model_extension_total_' . $result['code']}->getTotal($total_data);
					}
				}

				$sort_order = array();

				foreach ($totals as $key => $value) {
					$sort_order[$key] = $value['sort_order'];
				}

				array_multisort($sort_order, SORT_ASC, $totals);
			}

			$json['total'] = sprintf($this->language->get('text_items'), $this->cart->countProducts() + (isset($this->session->data['vouchers']) ? count($this->session->data['vouchers']) : 0), $this->currency->format($total, $this->session->data['currency']));
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	} // End function addToCart.

	protected function validateShoppinglistName($name) {
		$this->load->language('account/shoppinglists');
		
		$name = trim($name);
		if (utf8_strlen($name) === 0) {
			$this->error['shoppinglist_name'] = $this->language->get('error_missing_name');
		} elseif (utf8_strlen($name) > 32) {
			$this->error['shoppinglist_name'] = $this->language->get('error_name_too_long');
		} elseif (!preg_match('/^[\p{N}\p{L} \'_\-]{1,32}$/ui', $name)) {
			$this->error['shoppinglist_name'] = $this->language->get('error_name_invalid');
		} else {
			$this->load->model('account/shoppinglists');
			
			if ($this->model_account_shoppinglists->shoppinglistNameExists($name)) {
				$this->error['shoppinglist_name'] = $this->language->get('error_name_exists');
			}
		}
		
		return !$this->error;
	} // End function validateShoppinglistName.

	protected function validateQuantity($number) {
		$this->load->language('account/shoppinglists');

		if ($this->request->post['quantity_' . $number] == "") {
			$this->error['quantity_' . $number] = $this->language->get('error_missing_quantity');
		} elseif (!preg_match('/^[0-9]+$/', $this->request->post['quantity_' . $number])) {
			$this->error['quantity_' . $number] = $this->language->get('error_quantity_invalid');
		}

		return !$this->error;		
	} // End function validateQuantity.
}
?>
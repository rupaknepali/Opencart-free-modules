<?php
class ModelAccountShoppinglists extends Model {
	public function getTotalShoppinglists() {
		$query = $this->db->query("SELECT `id` FROM `" . DB_PREFIX . "customer_shoppinglist` WHERE `customer_id` = " . (int)$this->customer->getId());

		return $query->num_rows;
	}

	public function getShoppinglists() {
		$shoppinglist_data = array();

		$query = $this->db->query("SELECT `id`,`name` FROM `" . DB_PREFIX . "customer_shoppinglist` WHERE `customer_id` = " . (int)$this->customer->getId() . " ORDER BY `id`");

		foreach ($query->rows as $result) {
			$shoppinglist_data[$result['id']] = array(
				'id'     => $result['id'],
				'name'   => $result['name'],
				'show'   => $this->url->link('account/shoppinglists/show', 'shoppinglist_id=' . $result['id'], true),
				'delete' => $this->url->link('account/shoppinglists/delete', 'shoppinglist_id=' . $result['id'], true)
			);
		}

		return $shoppinglist_data;
	}

	public function addShoppinglist($name) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "customer_shoppinglist` SET `name` = '" . $this->db->escape($name) . "', `customer_id` = " . (int)$this->customer->getId() . ", `date_created` = NOW()");

		return ($this->db->getLastId() > 0) ? $this->db->getLastId(): false;
	}

	public function shoppinglistNameExists($name) {
		$query = $this->db->query("SELECT `id` FROM `" . DB_PREFIX . "customer_shoppinglist` WHERE `customer_id` = " . (int)$this->customer->getId() . " AND `name` = '" . $this->db->escape($name) . "'");

		return ($query->num_rows > 0) ? true: false;
	}

	public function getShoppinglistName($id) {
		$query = $this->db->query("SELECT `name` FROM `" . DB_PREFIX . "customer_shoppinglist` WHERE `customer_id` = " . (int)$this->customer->getId() . " AND `id` = " . (int)$id);

		return ($query->num_rows === 1) ? $query->row['name']: '';
	}

	public function deleteShoppinglist($id) {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "customer_shoppinglist` WHERE `customer_id` = " . (int)$this->customer->getId() . " AND `id` = " . (int)$id);

		return ($this->db->countAffected() > 0) ? true: false;
	}

	public function addProduct($shoppinglist, $product, $quantity, $option, $recurring) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "customer_shoppinglist_product` SET `shopping_list` = " . (int)$shoppinglist . ", `product_id` = " . (int)$product . ", `quantity` = " . (int)$quantity . ", `has_option` = " . (int)$option . ", `is_recurring` = " . (int)$recurring . ", `date_added` = NOW()");
		
		return ($this->db->countAffected() > 0) ? true: false;
	}

	public function checkRecurringProduct($product) {
		$query = $this->db->query("SELECT `product_id` FROM  `" . DB_PREFIX . "product_recurring` WHERE  `product_id` = " . (int)$product);

		return ($query->num_rows > 0) ? 1: 0;
	}

	public function updateProduct($shoppinglist, $product, $quantity) {
		$this->db->query("UPDATE `" . DB_PREFIX . "customer_shoppinglist_product` SET `quantity` = " . (int)$quantity . " WHERE `shopping_list` = " . (int)$shoppinglist . " AND `product_id` = " . (int)$product);
		
		return ($this->db->countAffected() >= 0) ? true: false;
	}

	public function deleteProduct($product, $shoppinglist) {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "customer_shoppinglist_product` WHERE `product_id` = " . (int)$product . " AND `shopping_list` = " . (int)$shoppinglist);

		return ($this->db->countAffected() >= 0) ? true: false;
	}

	public function productExists($product, $shoppinglist) {
		$query = $this->db->query("SELECT `product_id` FROM `" . DB_PREFIX . "customer_shoppinglist_product` WHERE `product_id` = " . (int)$product . " AND `shopping_list` = " . (int)$shoppinglist);

		return ($query->num_rows > 0) ? true: false;
	}

	public function getProducts($shoppinglist) {
		$products_data = array();

		$query = $this->db->query("SELECT `sp`.`product_id`,`sp`.`quantity`,`is_recurring`,`has_option` FROM `" . DB_PREFIX . "customer_shoppinglist_product` sp, `" . DB_PREFIX . "product` p WHERE `sp`.`product_id` = `p`.`product_id` AND `p`.`status` = 1 AND `shopping_list` = " . (int)$shoppinglist . " ORDER BY `sp`.`date_added`");

		foreach ($query->rows as $result) {
			$products_data[$result['product_id']] = array(
				'id'           => $result['product_id'],
				'quantity'     => $result['quantity'],
				'is_recurring' => $result['is_recurring'],
				'has_option'   => $result['has_option']
			);
		}

		return $products_data;
	}
}
?>
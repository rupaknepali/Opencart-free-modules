class App {
  constructor () {
    console.info('ES6 Modules work!');
  }
}

export default App;


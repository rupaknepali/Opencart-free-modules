# gulp-es6
Gulpfile setup for Javascript ES6 compiling, plus SCSS, images, and fonts handling

<?php

namespace Drupal\ajax_page_state_fix\EventSubscriber;

use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class AjaxPageStateSanitizer implements EventSubscriberInterface {

  protected $requestStack;

  public function __construct(RequestStack $requestStack) {
    $this->requestStack = $requestStack;
  }

  public static function getSubscribedEvents() {
    // PRIORITY 300 = run BEFORE Drupal does any request processing.
    return [
      KernelEvents::REQUEST => ['sanitizeSuperglobals', 300],
    ];
  }

  /**
   * Sanitize $_GET and $_POST *before* Drupal touches them.
   */
  public function sanitizeSuperglobals(RequestEvent $event) {
    $request = $event->getRequest();
    $clean = false;

    // --------- CLEAN GET ----------
    if (isset($_GET['ajax_page_state']) && is_array($_GET['ajax_page_state'])) {
      unset($_GET['ajax_page_state']['libraries']);
      unset($_GET['ajax_page_state']['theme_token']);
      if (empty($_GET['ajax_page_state'])) {
        unset($_GET['ajax_page_state']);
      }
      $clean = true;
    }

    // --------- CLEAN POST ----------
    if (isset($_POST['ajax_page_state']) && is_array($_POST['ajax_page_state'])) {
      unset($_POST['ajax_page_state']['libraries']);
      unset($_POST['ajax_page_state']['theme_token']);
      if (empty($_POST['ajax_page_state'])) {
        unset($_POST['ajax_page_state']);
      }
      $clean = true;
    }

    // ---- SYNC with Request object ----
    $request->query->replace($_GET);
    $request->request->replace($_POST);

    // If GET had invalid values → redirect to cleaned URL.
    if ($clean && $request->isMethod('GET')) {
      $clean_url = $request->getSchemeAndHttpHost() . $request->getPathInfo();
      if (!empty($_GET)) {
        $clean_url .= '?' . http_build_query($_GET);
      }
      $event->setResponse(new RedirectResponse($clean_url));
    }
  }

}
